console.log("Payments service running");
